package test;

import static org.junit.Assert.assertTrue;


import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;

public class TestingConnectivity {
	@Test
	/****
	 * Testing if the right database is accessed.
	 */
	public void testDatabaseAccess(){
		try {
			 DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","root");
		} catch (SQLException e) {
			assertTrue(false);
			return;
		}
		assertTrue(true);
	}
}
