package test;
import static org.junit.Assert.assertFalse;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
public class TestPETSDatabaseInsertion {
@Test
public void test() throws SQLException {
	//Launch the PETS
	Alert al = new Alert(AlertType.INFORMATION);
	al.setContentText("PETS will launch. Close the window to finish testing.");
	mainline.Mainline.main(null);
	//Once PETS is launched, modify the key fields
	actions.ListItem.theItemName = "TestingItemEntry";
	actions.ListItem.theItemDescription = "TestingItemDescription";
	//Clicking on Add to Bottom Button
	actions.ListItem.btnAddBottom.fire();
	//Establishing connection with the database
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","root");
	//Retrieve query
	Statement retrieveStatement = conn.createStatement();
	String rq = "select * from lc where LifeCycleName = \"TestingItemEntry\"";
	//Execute the retrieval
	ResultSet rs = retrieveStatement.executeQuery(rq);
	//If only one row is retrieved then the PETS is saving data correctly.
	assertFalse(rs==null);
	
	
}


}
