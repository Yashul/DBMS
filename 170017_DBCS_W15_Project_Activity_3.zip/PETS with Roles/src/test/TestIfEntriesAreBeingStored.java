package test;

import static org.junit.Assert.assertFalse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

public class TestIfEntriesAreBeingStored {
	/***
	 * Testing if the entries are actually being saved to the database.
	 * Taking example of lifecycle tab
	 * @throws SQLException
	 */
	@Test
	public void testIfEntriesAreGettingStored() throws SQLException {
		// Establishing a connection.
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","root");
		String q = "INSERT INTO lc(LifeCycleName, LifeCycleDescription) "+"VALUES"+"(?,?,?)";
		PreparedStatement prStatement = conn.prepareStatement(q);
		prStatement.setInt(1, 1215);
		prStatement.setString(2, "TestLifeCycle");
		prStatement.setString(3, "Test is the motive");
		prStatement.execute();
		Statement retrieveStatement = conn.createStatement();
		String rq = "select * from lc";
		ResultSet rs = retrieveStatement.executeQuery(rq);
		assertFalse(rs==null);
	}
}
