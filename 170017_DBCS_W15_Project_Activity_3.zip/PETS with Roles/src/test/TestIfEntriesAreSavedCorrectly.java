package test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

public class TestIfEntriesAreSavedCorrectly {

	
	/***
	 * Testing if the entries stored are stored in right attributes.
	 * @throws SQLException 
	 */
	@Test
	public void testIfEntriesAreSavedCorrectly() throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","root");
		Statement retrieveStatement = conn.createStatement();
		String rq = "select * from lc";
		ResultSet rs = retrieveStatement.executeQuery(rq);
		String theActualName = rs.getString("LifeCycleName");
		String theActualDescription = rs.getString("LifeCycleDescription");
		String theExpectedName = "TestLifeCycle";
		String theExpectedDescription = "Test is the motive";
		assertTrue(theActualName==theExpectedName&&theExpectedDescription==theActualDescription);
	}
	
	

}
